import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image/image.dart' as img;

enum OutFormat { jpg, png, webp }

extension OutFormatX on OutFormat {
  String get ext => switch (this) {
        OutFormat.jpg => 'jpg',
        OutFormat.png => 'png',
        OutFormat.webp => 'webp',
      };
  String get label => ext.toUpperCase();
}

class CompressionException implements Exception {
  CompressionException(this.message);
  final String message;
  @override
  String toString() => message;
}

class CompressionRequest {
  const CompressionRequest({
    required this.bytes,
    required this.maxBytes,
    this.width,
    this.height,
    this.keepAspect = true,
    this.format = OutFormat.jpg,
    this.grayscale = false,
  });
  final Uint8List bytes;
  final int maxBytes;
  final int? width, height;
  final bool keepAspect, grayscale;
  final OutFormat format;
}

class CompressionResult {
  const CompressionResult({
    required this.bytes,
    required this.width,
    required this.height,
    required this.quality,
    required this.metTarget,
    required this.reducedDimensions,
  });
  final Uint8List bytes;
  final int width, height, quality;
  final bool metTarget;

  /// True if pixel dimensions had to shrink below what was requested
  /// to reach the size target.
  final bool reducedDimensions;
}

class _Stage {
  _Stage.done(this.done)
      : intermediate = null, w = 0, h = 0;
  _Stage.webp(this.intermediate, this.w, this.h) : done = null;
  final CompressionResult? done;
  final Uint8List? intermediate;
  final int w, h;
}

const int _minQ = 5;
const int _maxQ = 95;
const int _autoMaxSide = 4096; // memory guard when no dimensions requested

/// Target-size engine.
///
/// Strategy: for a given pixel size, binary-search the HIGHEST quality whose
/// output is <= target (≈7 encodes). If even the minimum quality is too big,
/// shrink pixels using sqrt(target/size) as a smart first guess (so we don't
/// loop 10 times) and search again.
///
/// Memory: decode/resize/encode run in a background isolate, so the UI never
/// janks, and giant photos are capped at 4096px unless exact dims are given.
class CompressionEngine {
  static const maxInputBytes = 60 * 1024 * 1024;

  static Future<CompressionResult> compress(CompressionRequest r) async {
    if (r.maxBytes < 2 * 1024) {
      throw CompressionException('Target must be at least 2 KB.');
    }
    if (r.bytes.length > maxInputBytes) {
      throw CompressionException('Image is too large (max 60 MB).');
    }
    try {
      final stage = await compute(_process, r);
      if (stage.done != null) return stage.done!;
      return await _finishWebp(stage, r.maxBytes);
    } on CompressionException {
      rethrow;
    } catch (e) {
      throw CompressionException('Compression failed. The image may be corrupted or too large.');
    }
  }

  // WebP: `image` can't encode it, so use the native encoder (also off the UI thread).
  static Future<CompressionResult> _finishWebp(_Stage s, int maxBytes) async {
    var w = s.w, h = s.h;
    var reduced = false;
    Future<Uint8List> enc(int q) => FlutterImageCompress.compressWithList(
          s.intermediate!,
          minWidth: w,
          minHeight: h,
          quality: q,
          format: CompressFormat.webp,
          keepExif: false,
        );

    for (var attempt = 0; attempt < 8; attempt++) {
      final floor = await enc(_minQ);
      if (floor.length <= maxBytes) {
        var best = floor, bestQ = _minQ, lo = _minQ + 1, hi = _maxQ;
        while (lo <= hi) {
          final mid = (lo + hi) >> 1;
          final out = await enc(mid);
          if (out.length <= maxBytes) {
            best = out; bestQ = mid; lo = mid + 1;
          } else {
            hi = mid - 1;
          }
        }
        return CompressionResult(
            bytes: best, width: w, height: h, quality: bestQ,
            metTarget: true, reducedDimensions: reduced);
      }
      final f = (math.sqrt(maxBytes / floor.length) * 0.95).clamp(0.4, 0.92);
      w = math.max(16, (w * f).round());
      h = math.max(16, (h * f).round());
      reduced = true;
    }
    final out = await enc(_minQ);
    return CompressionResult(
        bytes: out, width: w, height: h, quality: _minQ,
        metTarget: out.length <= maxBytes, reducedDimensions: reduced);
  }
}

// ───────────── runs inside the background isolate ─────────────

_Stage _process(CompressionRequest r) {
  img.Image? im = img.decodeImage(r.bytes);
  if (im == null) throw CompressionException('Unsupported or corrupted image.');
  im = img.bakeOrientation(im); // respect EXIF rotation
  if (r.grayscale) im = img.grayscale(im);
  im = _applyDims(im, r);

  switch (r.format) {
    case OutFormat.jpg:
      return _Stage.done(
          _searchLossy(im, r.maxBytes, (i, q) => img.encodeJpg(i, quality: q)));
    case OutFormat.png:
      return _Stage.done(_searchPng(im, r.maxBytes));
    case OutFormat.webp:
      return _Stage.webp(img.encodeJpg(im, quality: 95), im.width, im.height);
  }
}

img.Image _applyDims(img.Image im, CompressionRequest r) {
  final tw = r.width, th = r.height;
  if (tw != null && th != null) {
    return img.copyResize(im,
        width: tw, height: th,
        maintainAspect: r.keepAspect,
        interpolation: img.Interpolation.average);
  }
  if (tw != null || th != null) {
    return img.copyResize(im,
        width: tw, height: th, interpolation: img.Interpolation.average);
  }
  final longest = math.max(im.width, im.height);
  if (longest > _autoMaxSide) {
    return img.copyResize(im,
        width: im.width >= im.height ? _autoMaxSide : null,
        height: im.height > im.width ? _autoMaxSide : null,
        interpolation: img.Interpolation.average);
  }
  return im;
}

img.Image _shrink(img.Image im, double sizeRatio) {
  final f = (math.sqrt(sizeRatio) * 0.95).clamp(0.4, 0.92);
  return img.copyResize(im,
      width: math.max(16, (im.width * f).round()),
      interpolation: img.Interpolation.average);
}

CompressionResult _searchLossy(
    img.Image base, int maxBytes, Uint8List Function(img.Image, int) enc) {
  var im = base;
  var reduced = false;
  for (var attempt = 0; attempt < 8; attempt++) {
    final floor = enc(im, _minQ);
    if (floor.length <= maxBytes) {
      var best = floor, bestQ = _minQ, lo = _minQ + 1, hi = _maxQ;
      while (lo <= hi) {
        final mid = (lo + hi) >> 1;
        final out = enc(im, mid);
        if (out.length <= maxBytes) {
          best = out; bestQ = mid; lo = mid + 1;
        } else {
          hi = mid - 1;
        }
      }
      return CompressionResult(
          bytes: best, width: im.width, height: im.height, quality: bestQ,
          metTarget: true, reducedDimensions: reduced);
    }
    im = _shrink(im, maxBytes / floor.length);
    reduced = true;
  }
  final out = enc(im, _minQ);
  return CompressionResult(
      bytes: out, width: im.width, height: im.height, quality: _minQ,
      metTarget: out.length <= maxBytes, reducedDimensions: reduced);
}

// PNG is lossless: there is no quality knob, so size is controlled by pixels.
CompressionResult _searchPng(img.Image base, int maxBytes) {
  var im = base;
  var out = img.encodePng(im, level: 6);
  var reduced = false;
  for (var i = 0; i < 12 && out.length > maxBytes && im.width > 16; i++) {
    im = _shrink(im, maxBytes / out.length);
    out = img.encodePng(im, level: 6);
    reduced = true;
  }
  return CompressionResult(
      bytes: out, width: im.width, height: im.height, quality: 100,
      metTarget: out.length <= maxBytes, reducedDimensions: reduced);
}
