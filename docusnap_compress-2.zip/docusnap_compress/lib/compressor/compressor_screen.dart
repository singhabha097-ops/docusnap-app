import '../core/app_config.dart';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import '../core/utils.dart';
import '../editor/editor_screen.dart';
import '../monetization/ad_manager.dart';
import '../monetization/banner_ad_widget.dart';
import '../monetization/paywall_screen.dart';
import '../monetization/premium_controller.dart';
import 'compression_engine.dart';

class _Preset {
  const _Preset(this.label, this.minKb, this.maxKb);
  final String label;
  final int minKb, maxKb;
}

const _presets = [
  _Preset('Signature 10–20 KB', 10, 20),
  _Preset('Photo 20–50 KB', 20, 50),
];

class CompressorScreen extends StatefulWidget {
  const CompressorScreen({super.key, this.initialPath, this.openBatchOnStart = false});
  final String? initialPath;
  final bool openBatchOnStart;
  @override
  State<CompressorScreen> createState() => _CompressorScreenState();
}

class _CompressorScreenState extends State<CompressorScreen> {
  static const _minKb = 5.0, _maxKb = 2048.0;

  final _picker = ImagePicker();
  final _wCtrl = TextEditingController();
  final _hCtrl = TextEditingController();

  String? _path;
  int _origBytes = 0;
  double _sliderV = 0.383; // ≈ 50 KB on the log scale
  int? _presetMinKb;
  OutFormat _format = OutFormat.jpg;
  bool _useCm = false, _keepAspect = true, _gray = false;
  bool _busy = false;
  CompressionResult? _result;
  int _batchDone = 0, _batchTotal = 0;

  int get _targetKb =>
      (_minKb * math.pow(_maxKb / _minKb, _sliderV)).round().clamp(5, 2048).toInt();

  void _setTargetKb(int kb, {int? min}) {
    _sliderV = (math.log(kb / _minKb) / math.log(_maxKb / _minKb)).clamp(0.0, 1.0).toDouble();
    _presetMinKb = min;
  }

  String get _targetLabel =>
      _targetKb >= 1024 ? '${(_targetKb / 1024).toStringAsFixed(1)} MB' : '$_targetKb KB';

  @override
  void initState() {
    super.initState();
    if (widget.initialPath != null) _setFile(widget.initialPath!);
    if (widget.openBatchOnStart) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _batch());
    }
  }

  @override
  void dispose() {
    _wCtrl.dispose();
    _hCtrl.dispose();
    super.dispose();
  }

  Future<void> _setFile(String path) async {
    final len = await File(path).length();
    if (!mounted) return;
    setState(() {
      _path = path;
      _origBytes = len;
      _result = null;
    });
  }

  Future<void> _pick(ImageSource s) async {
    try {
      final x = await _picker.pickImage(source: s);
      if (x != null) await _setFile(x.path);
    } catch (e) {
      if (mounted) showSnack(context, 'Could not open image.');
    }
  }

  (int?, int?) _dims() {
    final w = double.tryParse(_wCtrl.text.trim());
    final h = double.tryParse(_hCtrl.text.trim());
    int? conv(double? v) {
      if (v == null || v <= 0) return null;
      return _useCm ? cmToPx(v) : v.round();
    }
    return (conv(w), conv(h));
  }

  CompressionRequest _request(Uint8List bytes) {
    final (w, h) = _dims();
    return CompressionRequest(
      bytes: bytes,
      maxBytes: _targetKb * 1024,
      width: w, height: h,
      keepAspect: _keepAspect,
      format: _format,
      grayscale: _gray,
    );
  }

  Future<void> _compress() async {
    if (_path == null) return;
    setState(() => _busy = true);
    try {
      final bytes = await File(_path!).readAsBytes();
      final res = await CompressionEngine.compress(_request(bytes));
      if (mounted) setState(() => _result = res);
    } on CompressionException catch (e) {
      if (mounted) showSnack(context, e.message);
    } catch (_) {
      if (mounted) showSnack(context, 'Something went wrong. Try another image.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveBytes(Uint8List bytes) async {
    final dir = await getTemporaryDirectory();
    final name =
        'docusnap_${DateTime.now().microsecondsSinceEpoch}.${_format.ext}';
    final f = File(p.join(dir.path, name));
    await f.writeAsBytes(bytes, flush: true);
    await Gal.putImage(f.path, album: 'DocuSnap');
    await f.delete();
  }

  Future<void> _save() async {
    final r = _result;
    if (r == null) return;
    try {
      await _saveBytes(r.bytes);
      if (!mounted) return;
      showSnack(context, 'Saved to Gallery › DocuSnap');
      // Interstitial ONLY after a successful save (premium + cooldown handled inside).
      await context.read<AdManager>().showInterstitialAfterSave();
    } on GalException catch (e) {
      if (mounted) showSnack(context, 'Could not save: ${e.type.message}');
    } catch (_) {
      if (mounted) showSnack(context, 'Could not save the image.');
    }
  }

  // Premium: up to 20 images, processed sequentially to keep memory flat.
  Future<void> _batch() async {
    if (!context.read<PremiumController>().isPremium) {
      await pushPage(context, const PaywallScreen());
      return;
    }
    try {
      final picks = await _picker.pickMultiImage(limit: 20);
      if (picks.isEmpty) return;
      final files = picks.take(20).toList();
      setState(() {
        _batchTotal = files.length;
        _batchDone = 0;
        _busy = true;
      });
      var ok = 0;
      for (final x in files) {
        try {
          final res = await CompressionEngine.compress(
              _request(await File(x.path).readAsBytes()));
          await _saveBytes(res.bytes);
          ok++;
        } catch (_) {/* skip bad file, continue */}
        if (mounted) setState(() => _batchDone++);
      }
      if (mounted) showSnack(context, 'Batch done: $ok of ${files.length} saved.');
    } finally {
      if (mounted) setState(() { _busy = false; _batchTotal = 0; });
    }
  }

  Future<void> _edit() async {
    if (_path == null) return;
    final newPath = await pushPage<String>(context, EditorScreen(path: _path!));
    if (newPath != null) await _setFile(newPath);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final premium = context.watch<PremiumController>().isPremium;
    return Scaffold(
      appBar: AppBar(title: const Text('Photo Compressor'), actions: [
        if (!AppConfig.adsOnly)
        IconButton(
          tooltip: premium ? 'Batch (20)' : 'Batch · Premium',
          icon: Icon(premium ? Icons.collections : Icons.lock_outline),
          onPressed: _busy ? null : _batch,
        ),
      ]),
      bottomNavigationBar: const BannerAdWidget(),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _sourceCard(cs),
        const SizedBox(height: 16),
        Text('Target size', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 4, children: [
          for (final pr in _presets)
            ChoiceChip(
              label: Text(pr.label),
              selected: _presetMinKb == pr.minKb && _targetKb == pr.maxKb,
              onSelected: (_) => setState(() => _setTargetKb(pr.maxKb, min: pr.minKb)),
            ),
          for (final kb in [100, 200, 500, 1024])
            ActionChip(
              label: Text(kb >= 1024 ? '1 MB' : '$kb KB'),
              onPressed: () => setState(() => _setTargetKb(kb)),
            ),
        ]),
        Row(children: [
          Expanded(
            child: Slider(
              value: _sliderV,
              onChanged: (v) => setState(() { _sliderV = v; _presetMinKb = null; }),
            ),
          ),
          SizedBox(
            width: 84,
            child: Text('≤ $_targetLabel',
                textAlign: TextAlign.right,
                style: Theme.of(context).textTheme.titleSmall),
          ),
        ]),
        const SizedBox(height: 8),
        Text('Dimensions (optional)', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: _dimField(_wCtrl, 'Width')),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('×')),
          Expanded(child: _dimField(_hCtrl, 'Height')),
          const SizedBox(width: 8),
          SegmentedButton<bool>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: false, label: Text('px')),
              ButtonSegment(value: true, label: Text('cm')),
            ],
            selected: {_useCm},
            onSelectionChanged: (s) => setState(() => _useCm = s.first),
          ),
        ]),
        Wrap(spacing: 8, children: [
          ActionChip(
            label: const Text('3.5×4.5 cm photo'),
            onPressed: () => setState(() {
              _useCm = true; _wCtrl.text = '3.5'; _hCtrl.text = '4.5';
            }),
          ),
          ActionChip(
            label: const Text('Clear'),
            onPressed: () => setState(() { _wCtrl.clear(); _hCtrl.clear(); }),
          ),
        ]),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Keep aspect ratio'),
          subtitle: const Text('Off = stretch to exact W×H'),
          value: _keepAspect,
          onChanged: (v) => setState(() => _keepAspect = v),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Black & white'),
          value: _gray,
          onChanged: (v) => setState(() => _gray = v),
        ),
        const SizedBox(height: 4),
        Text('Format', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        SegmentedButton<OutFormat>(
          segments: [for (final f in OutFormat.values) ButtonSegment(value: f, label: Text(f.label))],
          selected: {_format},
          onSelectionChanged: (s) => setState(() => _format = s.first),
        ),
        if (_format == OutFormat.png)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text('PNG is lossless — small targets will shrink pixel dimensions. Prefer JPG for exam forms.',
                style: Theme.of(context).textTheme.bodySmall),
          ),
        const SizedBox(height: 16),
        if (_batchTotal > 0) ...[
          LinearProgressIndicator(value: _batchDone / _batchTotal),
          const SizedBox(height: 4),
          Text('Batch: $_batchDone / $_batchTotal'),
          const SizedBox(height: 12),
        ],
        FilledButton.icon(
          onPressed: (_path == null || _busy) ? null : _compress,
          icon: _busy
              ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.compress),
          label: Text(_busy ? 'Working…' : 'Compress to ≤ $_targetLabel'),
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
        ),
        if (_result != null) _resultCard(cs),
        const SizedBox(height: 16),
      ]),
    );
  }

  Widget _sourceCard(ColorScheme cs) => Card(
        clipBehavior: Clip.antiAlias,
        child: Column(children: [
          if (_path != null)
            SizedBox(
              height: 180, width: double.infinity,
              child: Image.file(File(_path!), fit: BoxFit.contain, cacheWidth: 900),
            )
          else
            Container(
              height: 120, color: cs.surfaceContainerHighest,
              alignment: Alignment.center,
              child: const Text('Choose a photo to begin'),
            ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Wrap(spacing: 8, alignment: WrapAlignment.center, children: [
              OutlinedButton.icon(
                onPressed: _busy ? null : () => _pick(ImageSource.gallery),
                icon: const Icon(Icons.photo_library_outlined), label: const Text('Gallery')),
              OutlinedButton.icon(
                onPressed: _busy ? null : () => _pick(ImageSource.camera),
                icon: const Icon(Icons.photo_camera_outlined), label: const Text('Camera')),
              if (_path != null)
                OutlinedButton.icon(
                  onPressed: _busy ? null : _edit,
                  icon: const Icon(Icons.tune), label: const Text('Edit')),
            ]),
          ),
          if (_path != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text('Original: ${formatBytes(_origBytes)}'),
            ),
        ]),
      );

  Widget _dimField(TextEditingController c, String label) => TextField(
        controller: c,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(labelText: label, isDense: true, border: const OutlineInputBorder()),
      );

  Widget _resultCard(ColorScheme cs) {
    final r = _result!;
    final belowMin = _presetMinKb != null && r.bytes.length < _presetMinKb! * 1024;
    return Card(
      margin: const EdgeInsets.only(top: 16),
      color: r.metTarget ? cs.primaryContainer : cs.errorContainer,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          Row(children: [
            Icon(r.metTarget ? Icons.check_circle : Icons.warning_amber_rounded),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                '${formatBytes(_origBytes)} → ${formatBytes(r.bytes.length)}',
                style: Theme.of(context).textTheme.titleMedium),
            ),
          ]),
          const SizedBox(height: 4),
          Align(
            alignment: Alignment.centerLeft,
            child: Text('${r.width}×${r.height}px · ${_format.label}'
                '${_format == OutFormat.png ? '' : ' · quality ${r.quality}'}'),
          ),
          if (r.reducedDimensions)
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Pixels were reduced to reach the size limit.'),
            ),
          if (!r.metTarget)
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Could not reach the target; try a larger limit.'),
            ),
          if (belowMin)
            Align(
              alignment: Alignment.centerLeft,
              child: Text('Note: result is under the $_presetMinKb KB minimum; the source image is very small/simple.'),
            ),
          const SizedBox(height: 8),
          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 200),
            child: Image.memory(r.bytes, fit: BoxFit.contain),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: _save,
            icon: const Icon(Icons.download),
            label: const Text('Save to Gallery'),
          ),
        ]),
      ),
    );
  }
}
