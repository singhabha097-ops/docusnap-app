/// Build-time switch for the "ads-only" edition (Samsung Galaxy Store, Indus AppStore, etc.).
///
///   Google Play build : flutter build appbundle --release
///   Ads-only build    : flutter build apk --release --dart-define=ADS_ONLY=true
///
/// In ads-only mode there is no paywall, no billing initialisation and no
/// Premium upsell anywhere in the UI. Ads still run (banner, cooldown interstitial).
class AppConfig {
  static const bool adsOnly = bool.fromEnvironment('ADS_ONLY', defaultValue: false);
}
