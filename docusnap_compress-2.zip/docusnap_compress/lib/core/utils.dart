import 'package:flutter/material.dart';

String formatBytes(int b) {
  if (b < 1024) return '$b B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
  return '${(b / 1048576).toStringAsFixed(2)} MB';
}

/// Print-size to pixels (default 300 DPI). 3.5 cm -> 413 px, 4.5 cm -> 531 px.
int cmToPx(double cm, {int dpi = 300}) => (cm / 2.54 * dpi).round();

Future<T?> pushPage<T>(BuildContext c, Widget w) =>
    Navigator.of(c).push<T>(MaterialPageRoute(builder: (_) => w));

void showSnack(BuildContext c, String msg) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}
