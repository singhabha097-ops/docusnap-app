import 'dart:async';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'premium_controller.dart';

/// Google's official TEST unit IDs. Replace with your own before release.
class AdIds {
  static const banner = 'ca-app-pub-3940256099942544/6300978111';
  static const interstitial = 'ca-app-pub-3940256099942544/1033173712';
  static const appOpen = 'ca-app-pub-3940256099942544/9257395921';
  static const rewarded = 'ca-app-pub-3940256099942544/5224354917';
}

class AdManager {
  AdManager(this._premium) {
    _premium.addListener(_onPremiumChanged);
  }

  final PremiumController _premium;

  static const interstitialCooldown = Duration(minutes: 3);

  InterstitialAd? _interstitial;
  bool _loadingInterstitial = false;
  DateTime? _lastInterstitial;

  AppOpenAd? _appOpen;
  DateTime? _appOpenLoadedAt;
  bool _showingFullScreen = false;
  DateTime? _lastFullScreenDismiss;

  /// Set true while the Play purchase sheet is up so we don't show app-open ads.
  bool suppressAppOpen = false;

  /// THE gate: every ad call checks this first.
  bool get adsEnabled => !_premium.isPremium;

  Future<void> init() async {
    await MobileAds.instance.initialize();
    if (adsEnabled) {
      loadInterstitial();
      loadAppOpen();
      loadRewarded();
    }
  }

  // ── Interstitial ───────────────────────────────────────────────
  void loadInterstitial() {
    if (!adsEnabled || _loadingInterstitial || _interstitial != null) return;
    _loadingInterstitial = true;
    InterstitialAd.load(
      adUnitId: AdIds.interstitial,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitial = ad;
          _loadingInterstitial = false;
        },
        onAdFailedToLoad: (_) {
          _loadingInterstitial = false;
          Future.delayed(const Duration(seconds: 45), loadInterstitial);
        },
      ),
    );
  }

  /// Call ONLY after a successful compress+save. Respects premium + cooldown.
  Future<void> showInterstitialAfterSave() async {
    if (!adsEnabled) return;
    final last = _lastInterstitial;
    if (last != null && DateTime.now().difference(last) < interstitialCooldown) {
      return;
    }
    final ad = _interstitial;
    if (ad == null) {
      loadInterstitial();
      return;
    }
    _interstitial = null;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        _markDismissed();
        loadInterstitial();
      },
      onAdFailedToShowFullScreenContent: (a, _) {
        a.dispose();
        _markDismissed();
        loadInterstitial();
      },
    );
    _showingFullScreen = true;
    _lastInterstitial = DateTime.now();
    await ad.show();
  }

  // ── Rewarded video (opt-in: user taps "Watch video") ─────────────
  RewardedAd? _rewarded;
  bool _loadingRewarded = false;

  void loadRewarded() {
    if (!adsEnabled || _loadingRewarded || _rewarded != null) return;
    _loadingRewarded = true;
    RewardedAd.load(
      adUnitId: AdIds.rewarded,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewarded = ad;
          _loadingRewarded = false;
        },
        onAdFailedToLoad: (_) {
          _loadingRewarded = false;
          Future.delayed(const Duration(seconds: 30), loadRewarded);
        },
      ),
    );
  }

  /// Shows a rewarded video. Resolves true only if the user earned the reward.
  /// Premium users never see ads, so it resolves true immediately for them.
  Future<bool> showRewarded() async {
    if (!adsEnabled) return true;
    var ad = _rewarded;
    if (ad == null) {
      loadRewarded();
      for (var i = 0; i < 12 && _rewarded == null; i++) {
        await Future<void>.delayed(const Duration(milliseconds: 500));
      }
      ad = _rewarded;
      if (ad == null) return false; // no fill / offline
    }
    _rewarded = null;
    final done = Completer<bool>();
    var earned = false;
    void finish(bool v) {
      _markDismissed();
      _lastInterstitial = DateTime.now(); // no interstitial right after a video
      loadRewarded();
      if (!done.isCompleted) done.complete(v);
    }

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        finish(earned);
      },
      onAdFailedToShowFullScreenContent: (a, _) {
        a.dispose();
        finish(false);
      },
    );
    _showingFullScreen = true;
    await ad.show(onUserEarnedReward: (_, __) => earned = true);
    return done.future;
  }

  // ── App open ───────────────────────────────────────────────────
  bool get _appOpenFresh =>
      _appOpen != null &&
      _appOpenLoadedAt != null &&
      DateTime.now().difference(_appOpenLoadedAt!) < const Duration(hours: 4);

  void loadAppOpen() {
    if (!adsEnabled || _appOpen != null) return;
    AppOpenAd.load(
      adUnitId: AdIds.appOpen,
      request: const AdRequest(),
      adLoadCallback: AppOpenAdLoadCallback(
        onAdLoaded: (ad) {
          _appOpen = ad;
          _appOpenLoadedAt = DateTime.now();
        },
        onAdFailedToLoad: (_) {},
      ),
    );
  }

  void showAppOpenIfAvailable() {
    if (!adsEnabled || suppressAppOpen || _showingFullScreen) return;
    final d = _lastFullScreenDismiss;
    if (d != null && DateTime.now().difference(d) < const Duration(seconds: 5)) {
      return; // resume event caused by another ad closing
    }
    if (!_appOpenFresh) {
      _appOpen?.dispose();
      _appOpen = null;
      loadAppOpen();
      return;
    }
    final ad = _appOpen!;
    _appOpen = null;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (a) {
        a.dispose();
        _markDismissed();
        loadAppOpen();
      },
      onAdFailedToShowFullScreenContent: (a, _) {
        a.dispose();
        _markDismissed();
        loadAppOpen();
      },
    );
    _showingFullScreen = true;
    ad.show();
  }

  void _markDismissed() {
    _showingFullScreen = false;
    _lastFullScreenDismiss = DateTime.now();
  }

  void _onPremiumChanged() {
    if (!adsEnabled) {
      _interstitial?.dispose();
      _interstitial = null;
      _appOpen?.dispose();
      _appOpen = null;
      _rewarded?.dispose();
      _rewarded = null;
    } else {
      loadInterstitial();
      loadAppOpen();
      loadRewarded();
    }
  }
}
