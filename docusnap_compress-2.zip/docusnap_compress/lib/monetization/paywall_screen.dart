import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'billing_service.dart';
import 'premium_controller.dart';

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({super.key});
  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen> {
  String _selected = BillingService.annualId;

  @override
  Widget build(BuildContext context) {
    final billing = context.watch<BillingService>();
    final premium = context.watch<PremiumController>();
    final cs = Theme.of(context).colorScheme;
    final isLifetimeSel = _selected == BillingService.lifetimeId;

    return Scaffold(
      appBar: AppBar(title: const Text('DocuSnap Premium')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Icon(Icons.workspace_premium, size: 64, color: Colors.amber.shade700),
            const SizedBox(height: 8),
            Text(premium.isPremium ? "You're Premium" : 'Go Premium',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 20),
            const _Perk(Icons.block, '100% ad-free', 'No banners, interstitials or app-open ads'),
            const _Perk(Icons.collections, 'Batch compression', 'Compress up to 20 images at once'),
            const _Perk(Icons.picture_as_pdf, 'Big PDFs, no video ads', 'Convert 50–100 pages without watching a video'),
            const _Perk(Icons.speed, 'Pro document reader', 'Watermark-free PDF viewing'),
            const SizedBox(height: 20),
            if (premium.isPremium)
              Card(
                color: cs.primaryContainer,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(premium.isLifetime
                      ? 'Lifetime access is active. Thank you for supporting DocuSnap!'
                      : 'Thanks for supporting DocuSnap! Manage or cancel any time in '
                          'Google Play → Payments & subscriptions → Subscriptions.'),
                ),
              )
            else ...[
              _PlanCard(
                title: 'Annual Pass',
                price: billing.priceOf(BillingService.annualId, '₹499'),
                period: 'per year',
                usd: '≈ US\$6',
                badge: 'BEST VALUE FOR REGULAR USE',
                selected: _selected == BillingService.annualId,
                onTap: () => setState(() => _selected = BillingService.annualId),
              ),
              const SizedBox(height: 12),
              _PlanCard(
                title: 'Monthly Pass',
                price: billing.priceOf(BillingService.monthlyId, '₹49'),
                period: 'per month',
                usd: '≈ US\$0.60',
                selected: _selected == BillingService.monthlyId,
                onTap: () => setState(() => _selected = BillingService.monthlyId),
              ),
              const SizedBox(height: 12),
              _PlanCard(
                title: 'Lifetime',
                price: billing.priceOf(BillingService.lifetimeId, '₹999'),
                period: 'pay once',
                usd: '≈ US\$12',
                badge: 'NO RENEWALS, EVER',
                selected: isLifetimeSel,
                onTap: () => setState(() => _selected = BillingService.lifetimeId),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: (billing.loading || billing.purchasePending)
                    ? null
                    : () => billing.buy(_selected),
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                child: billing.purchasePending
                    ? const SizedBox(
                        height: 22, width: 22,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(isLifetimeSel ? 'Buy lifetime access' : 'Subscribe'),
              ),
              TextButton(
                onPressed: billing.restore,
                child: const Text('Restore purchases'),
              ),
            ],
            if (billing.error != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(billing.error!,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: cs.error)),
              ),
            const SizedBox(height: 12),
            Text(
              'Payment is charged to your Google Play account. Subscriptions renew '
              'automatically unless cancelled at least 24 hours before the end of the '
              'current period. Lifetime is a one-time purchase. Prices in your local '
              'currency are shown by Google Play; USD amounts are approximate.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

class _Perk extends StatelessWidget {
  const _Perk(this.icon, this.title, this.subtitle);
  final IconData icon;
  final String title, subtitle;
  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
        title: Text(title),
        subtitle: Text(subtitle),
      );
}

class _PlanCard extends StatelessWidget {
  const _PlanCard({
    required this.title, required this.price, required this.period,
    required this.selected, required this.onTap, this.badge, this.usd,
  });
  final String title, price, period;
  final String? badge, usd;
  final bool selected;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    // Show the approximate USD hint only when Play is showing rupees.
    final showUsd = usd != null && price.contains('₹');
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: selected ? cs.primary : cs.outlineVariant, width: selected ? 2 : 1),
          color: selected ? cs.primaryContainer.withOpacity(.4) : null,
        ),
        child: Row(children: [
          Icon(selected ? Icons.radio_button_checked : Icons.radio_button_off, color: cs.primary),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: Theme.of(context).textTheme.titleMedium),
              if (badge != null)
                Text(badge!, style: TextStyle(color: cs.tertiary, fontSize: 11, fontWeight: FontWeight.w700)),
            ]),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(price, style: Theme.of(context).textTheme.titleLarge),
            if (showUsd) Text(usd!, style: Theme.of(context).textTheme.bodySmall),
            Text(period, style: Theme.of(context).textTheme.bodySmall),
          ]),
        ]),
      ),
    );
  }
}
