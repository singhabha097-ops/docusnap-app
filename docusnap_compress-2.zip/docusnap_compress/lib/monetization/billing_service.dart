import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'ad_manager.dart';
import 'premium_controller.dart';

/// Google Play: Monthly ₹49 + Annual ₹499 (subscriptions) and Lifetime ₹999
/// (one-time product). Create them in Play Console with exactly these IDs.
class BillingService extends ChangeNotifier {
  BillingService(this._premium, this._ads);

  static const monthlyId = 'sub_monthly_49';
  static const annualId = 'sub_annual_499';
  static const lifetimeId = 'lifetime_999';
  static const _ids = {monthlyId, annualId, lifetimeId};

  final PremiumController _premium;
  final AdManager _ads;
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  Map<String, ProductDetails> products = {};
  bool storeAvailable = false;
  bool loading = true;
  bool purchasePending = false;
  String? error;
  bool _sawActive = false;

  Future<void> init() async {
    // Listen BEFORE any restore/purchase so no event is missed.
    _sub = _iap.purchaseStream.listen(
      _onPurchases,
      onError: (Object e) {
        error = e.toString();
        notifyListeners();
      },
    );
    try {
      storeAvailable = await _iap.isAvailable();
      if (storeAvailable) {
        await loadProducts();
        await restore();
      }
    } catch (e) {
      error = 'Billing unavailable: $e';
    }
    loading = false;
    notifyListeners();
  }

  Future<void> loadProducts() async {
    final r = await _iap.queryProductDetails(_ids);
    products = {for (final p in r.productDetails) p.id: p};
    if (r.error != null) error = r.error!.message;
  }

  String priceOf(String id, String fallback) => products[id]?.price ?? fallback;

  Future<void> buy(String id) async {
    error = null;
    final pd = products[id];
    if (pd == null) {
      error = 'Plan unavailable. Check your connection and try again.';
      notifyListeners();
      return;
    }
    _ads.suppressAppOpen = true;
    try {
      // Subscriptions AND the one-time lifetime product use buyNonConsumable on Android.
      await _iap.buyNonConsumable(
        purchaseParam: PurchaseParam(productDetails: pd),
      );
    } catch (e) {
      error = 'Could not start purchase: $e';
      _ads.suppressAppOpen = false;
      notifyListeners();
    }
  }

  /// Re-queries Play for active subscriptions (results arrive on the stream).
  Future<void> restore() async {
    if (!storeAvailable) return;
    _sawActive = false;
    try {
      await _iap.restorePurchases();
    } catch (e) {
      error = 'Restore failed: $e';
      notifyListeners();
      return;
    }
    await Future<void>.delayed(const Duration(seconds: 4));
    // Nothing active came back: lapse only after the offline grace window.
    if (!_sawActive) await _premium.checkGrace();
  }

  Future<void> _onPurchases(List<PurchaseDetails> list) async {
    for (final p in list) {
      if (!_ids.contains(p.productID)) continue;
      switch (p.status) {
        case PurchaseStatus.pending:
          purchasePending = true;
          break;
        case PurchaseStatus.error:
          purchasePending = false;
          error = p.error?.message ?? 'Purchase failed';
          _releaseAppOpenSuppression();
          break;
        case PurchaseStatus.canceled:
          purchasePending = false;
          _releaseAppOpenSuppression();
          break;
        case PurchaseStatus.purchased:
        case PurchaseStatus.restored:
          purchasePending = false;
          _sawActive = true;
          if (p.productID == lifetimeId) {
            await _premium.setLifetime();
          } else {
            await _premium.setActive();
          }
          _releaseAppOpenSuppression();
          break;
      }
      // Acknowledges the purchase on Android (required within 3 days).
      if (p.pendingCompletePurchase) {
        await _iap.completePurchase(p);
      }
    }
    notifyListeners();
  }

  void _releaseAppOpenSuppression() => Future.delayed(
      const Duration(seconds: 3), () => _ads.suppressAppOpen = false);

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
