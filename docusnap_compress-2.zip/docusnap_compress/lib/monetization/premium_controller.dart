import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Single source of truth for `isPremium`.
/// - Subscription: cached locally, re-verified with Play, 3-day offline grace.
/// - Lifetime: one-time purchase, never expires, no grace check.
class PremiumController extends ChangeNotifier {
  PremiumController._(this._p)
      : _sub = _p.getBool(_kSub) ?? false,
        _lifetime = _p.getBool(_kLifetime) ?? false;

  static const _kSub = 'is_premium';
  static const _kLifetime = 'is_lifetime';
  static const _kVerified = 'premium_last_verified_ms';
  static const graceDays = 3;

  final SharedPreferences _p;
  bool _sub;
  bool _lifetime;

  static Future<PremiumController> create() async {
    final c = PremiumController._(await SharedPreferences.getInstance());
    await c.checkGrace();
    return c;
  }

  bool get isPremium => _lifetime || _sub;
  bool get isLifetime => _lifetime;

  Future<void> setLifetime() async {
    await _p.setBool(_kLifetime, true);
    if (!_lifetime) {
      _lifetime = true;
      notifyListeners();
    }
  }

  /// Play confirmed an active subscription (purchase or restore).
  Future<void> setActive() async {
    await _p.setBool(_kSub, true);
    await _p.setInt(_kVerified, DateTime.now().millisecondsSinceEpoch);
    if (!_sub) {
      _sub = true;
      notifyListeners();
    }
  }

  /// Drops the SUBSCRIPTION flag if not re-verified within the grace window.
  Future<void> checkGrace() async {
    if (!_sub) return;
    final last = _p.getInt(_kVerified) ?? 0;
    final age = DateTime.now().millisecondsSinceEpoch - last;
    if (age > graceDays * 86400000) {
      _sub = false;
      await _p.setBool(_kSub, false);
      notifyListeners();
    }
  }
}
