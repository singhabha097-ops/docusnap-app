import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../core/utils.dart';
import 'editor_service.dart';

class PassportPreset implements CropAspectRatioPresetData {
  @override
  (int, int)? get data => (35, 45);
  @override
  String get name => 'Passport (3.5×4.5)';
}

/// Returns the edited file path via Navigator.pop, or null if cancelled.
class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, required this.path});
  final String path;
  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late String _basePath = widget.path;
  Uint8List? _baseBytes, _preview;
  EditParams _params = const EditParams();
  Timer? _debounce;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadBase();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  Future<void> _loadBase() async {
    try {
      _baseBytes = await File(_basePath).readAsBytes();
      await _refresh();
    } catch (_) {
      if (mounted) showSnack(context, 'Could not open image.');
    }
  }

  Future<void> _refresh() async {
    final src = _baseBytes;
    if (src == null) return;
    try {
      final out = await EditorService.preview(src, _params);
      if (mounted) setState(() => _preview = out);
    } catch (_) {
      if (mounted) showSnack(context, 'Preview failed.');
    }
  }

  void _update(EditParams np, {bool debounce = false}) {
    setState(() => _params = np);
    _debounce?.cancel();
    if (debounce) {
      _debounce = Timer(const Duration(milliseconds: 150), _refresh);
    } else {
      _refresh();
    }
  }

  /// Applies current edits at full-res and writes a temp JPEG.
  Future<String> _bake() async {
    final bytes = await EditorService.render(_baseBytes!, _params);
    final dir = await getTemporaryDirectory();
    final f = File(p.join(dir.path, 'edit_${DateTime.now().microsecondsSinceEpoch}.jpg'));
    await f.writeAsBytes(bytes, flush: true);
    return f.path;
  }

  Future<void> _crop() async {
    setState(() => _busy = true);
    try {
      final baked = await _bake(); // so crop sees rotation/filters
      final cropped = await ImageCropper().cropImage(
        sourcePath: baked,
        uiSettings: [
          AndroidUiSettings(
            toolbarTitle: 'Crop',
            lockAspectRatio: false, // freeform by default
            initAspectRatio: CropAspectRatioPreset.original,
            aspectRatioPresets: [
              CropAspectRatioPreset.original, // freeform
              CropAspectRatioPreset.square,   // 1:1
              CropAspectRatioPreset.ratio4x3,
              CropAspectRatioPreset.ratio16x9,
              PassportPreset(),
            ],
          ),
        ],
      );
      _basePath = cropped?.path ?? baked;
      _params = const EditParams();
      await _loadBase();
    } catch (_) {
      if (mounted) showSnack(context, 'Crop failed.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _done() async {
    setState(() => _busy = true);
    try {
      final path = _params.isDefault && _basePath != widget.path ? _basePath : await _bake();
      if (mounted) Navigator.of(context).pop(path);
    } catch (_) {
      if (mounted) {
        setState(() => _busy = false);
        showSnack(context, 'Could not apply edits.');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Edit'), actions: [
        TextButton(
          onPressed: _params.isDefault ? null : () => _update(const EditParams()),
          child: const Text('Reset'),
        ),
        TextButton(onPressed: _busy ? null : _done, child: const Text('Done')),
      ]),
      body: Column(children: [
        Expanded(
          child: Container(
            color: Colors.black12,
            alignment: Alignment.center,
            child: _preview == null
                ? const CircularProgressIndicator()
                : Image.memory(_preview!, fit: BoxFit.contain, gaplessPlayback: true),
          ),
        ),
        if (_busy) const LinearProgressIndicator(),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _tool(Icons.crop, 'Crop', _busy ? null : _crop),
            _tool(Icons.rotate_left, 'Left',
                () => _update(_params.copyWith(quarterTurns: _params.quarterTurns + 3))),
            _tool(Icons.rotate_right, 'Right',
                () => _update(_params.copyWith(quarterTurns: _params.quarterTurns + 1))),
            _tool(Icons.flip, 'Flip H', () => _update(_params.copyWith(flipH: !_params.flipH))),
            _tool(Icons.flip_camera_android, 'Flip V',
                () => _update(_params.copyWith(flipV: !_params.flipV))),
            _tool(Icons.invert_colors, 'B&W',
                () => _update(_params.copyWith(grayscale: !_params.grayscale)),
                active: _params.grayscale, color: cs.primary),
          ]),
        ),
        _slider('Brightness', _params.brightness,
            (v) => _update(_params.copyWith(brightness: v), debounce: true)),
        _slider('Contrast', _params.contrast,
            (v) => _update(_params.copyWith(contrast: v), debounce: true)),
        const SizedBox(height: 8),
      ]),
    );
  }

  Widget _tool(IconData i, String l, VoidCallback? onTap, {bool active = false, Color? color}) =>
      InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(i, color: active ? color : null),
            Text(l, style: const TextStyle(fontSize: 11)),
          ]),
        ),
      );

  Widget _slider(String label, double v, ValueChanged<double> on) => Row(children: [
        SizedBox(width: 96, child: Padding(padding: const EdgeInsets.only(left: 16), child: Text(label))),
        Expanded(child: Slider(value: v, min: 0.5, max: 1.5, onChanged: on)),
      ]);
}
