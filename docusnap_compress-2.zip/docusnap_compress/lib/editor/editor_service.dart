import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;

class EditParams {
  const EditParams({
    this.quarterTurns = 0,
    this.flipH = false,
    this.flipV = false,
    this.grayscale = false,
    this.brightness = 1.0, // 1.0 = unchanged
    this.contrast = 1.0,   // 1.0 = unchanged
  });
  final int quarterTurns;
  final bool flipH, flipV, grayscale;
  final double brightness, contrast;

  EditParams copyWith({
    int? quarterTurns, bool? flipH, bool? flipV, bool? grayscale,
    double? brightness, double? contrast,
  }) =>
      EditParams(
        quarterTurns: quarterTurns ?? this.quarterTurns,
        flipH: flipH ?? this.flipH,
        flipV: flipV ?? this.flipV,
        grayscale: grayscale ?? this.grayscale,
        brightness: brightness ?? this.brightness,
        contrast: contrast ?? this.contrast,
      );

  bool get isDefault =>
      quarterTurns % 4 == 0 && !flipH && !flipV && !grayscale &&
      brightness == 1.0 && contrast == 1.0;
}

class _Job {
  const _Job(this.bytes, this.params, this.maxSide, this.quality);
  final Uint8List bytes;
  final EditParams params;
  final int? maxSide;
  final int quality;
}

class EditorService {
  /// Fast preview on a downscaled copy.
  static Future<Uint8List> preview(Uint8List src, EditParams p) =>
      compute(_apply, _Job(src, p, 900, 85));

  /// Full resolution render (JPEG q95) used when the user taps Done / Crop.
  static Future<Uint8List> render(Uint8List src, EditParams p) =>
      compute(_apply, _Job(src, p, null, 95));
}

Uint8List _apply(_Job j) {
  var im = img.decodeImage(j.bytes);
  if (im == null) throw StateError('Cannot decode image');
  im = img.bakeOrientation(im);
  final ms = j.maxSide;
  if (ms != null && (im.width > ms || im.height > ms)) {
    im = img.copyResize(im,
        width: im.width >= im.height ? ms : null,
        height: im.height > im.width ? ms : null,
        interpolation: img.Interpolation.average);
  }
  final p = j.params;
  if (p.quarterTurns % 4 != 0) {
    im = img.copyRotate(im, angle: (p.quarterTurns % 4) * 90);
  }
  if (p.flipH) im = img.flip(im, direction: img.FlipDirection.horizontal);
  if (p.flipV) im = img.flip(im, direction: img.FlipDirection.vertical);
  if (p.brightness != 1.0 || p.contrast != 1.0) {
    im = img.adjustColor(im, brightness: p.brightness, contrast: p.contrast);
  }
  if (p.grayscale) im = img.grayscale(im);
  return img.encodeJpg(im, quality: j.quality);
}
