import 'core/app_config.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'home/home_screen.dart';
import 'monetization/ad_manager.dart';
import 'monetization/billing_service.dart';
import 'monetization/premium_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Cached premium flag is read from disk before the first frame, so the app
  // is correct offline and ads never flash for premium users.
  final premium = await PremiumController.create();
  final ads = AdManager(premium);
  final billing = BillingService(premium, ads);

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: premium),
      Provider.value(value: ads),
      ChangeNotifierProvider.value(value: billing),
    ],
    child: const DocuSnapApp(),
  ));

  // Non-blocking: UI is already on screen.
  unawaited(ads.init());
  if (!AppConfig.adsOnly) unawaited(billing.init()); // no Play Billing in ads-only edition
}

class DocuSnapApp extends StatefulWidget {
  const DocuSnapApp({super.key});
  @override
  State<DocuSnapApp> createState() => _DocuSnapAppState();
}

class _DocuSnapAppState extends State<DocuSnapApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      context.read<AdManager>().showAppOpenIfAvailable(); // no-op for premium
    }
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'DocuSnap & Compress',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
        darkTheme: ThemeData(
            colorSchemeSeed: Colors.teal, useMaterial3: true, brightness: Brightness.dark),
        home: const HomeScreen(),
      );
}
