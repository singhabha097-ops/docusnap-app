import '../core/app_config.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../compressor/compressor_screen.dart';
import '../core/utils.dart';
import '../editor/editor_screen.dart';
import '../monetization/banner_ad_widget.dart';
import '../monetization/paywall_screen.dart';
import '../monetization/premium_controller.dart';
import '../pdf_tools/pdf_tools_screen.dart';
import '../reader/reader_home_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Future<void> _editFlow(BuildContext context) async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (x == null || !context.mounted) return;
    final edited = await pushPage<String>(context, EditorScreen(path: x.path));
    if (edited != null && context.mounted) {
      await pushPage(context, CompressorScreen(initialPath: edited));
    }
  }

  @override
  Widget build(BuildContext context) {
    final premium = context.watch<PremiumController>().isPremium;
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('DocuSnap & Compress'),
        actions: [
          if (!AppConfig.adsOnly)
          IconButton(
            tooltip: premium ? 'Premium active' : 'Go Premium',
            icon: Icon(
              premium ? Icons.workspace_premium : Icons.workspace_premium_outlined,
              color: premium ? Colors.amber.shade700 : null),
            onPressed: () => pushPage(context, const PaywallScreen()),
          ),
        ],
      ),
      bottomNavigationBar: const BannerAdWidget(),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (!premium && !AppConfig.adsOnly)
          Card(
            color: cs.primaryContainer,
            child: ListTile(
              leading: const Icon(Icons.workspace_premium),
              title: const Text('Go ad-free + batch compress'),
              subtitle: const Text('From ₹49/month'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => pushPage(context, const PaywallScreen()),
            ),
          ),
        const SizedBox(height: 12),
        GridView.count(
          crossAxisCount: 2, shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.05,
          children: [
            _FeatureCard(Icons.compress, 'Compress Photo', 'Hit exact KB targets',
                () => pushPage(context, const CompressorScreen())),
            _FeatureCard(Icons.tune, 'Edit Image', 'Crop, rotate, B&W',
                () => _editFlow(context)),
            _FeatureCard(Icons.swap_horiz, 'PDF Tools', 'Image ↔ PDF',
                () => pushPage(context, const PdfToolsScreen())),
            _FeatureCard(Icons.picture_as_pdf, 'Doc Reader', 'PDF, DOCX, XLSX…',
                () => pushPage(context, const ReaderHomeScreen())),
            if (!AppConfig.adsOnly)
            _FeatureCard(Icons.collections, 'Batch Compress',
                premium ? 'Up to 20 images' : 'Premium feature',
                () => pushPage(
                    context,
                    premium
                        ? const CompressorScreen(openBatchOnStart: true)
                        : const PaywallScreen()),
                locked: !premium),
          ],
        ),
        const SizedBox(height: 16),
        Text('Works fully offline. Your files never leave your phone.',
            textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  const _FeatureCard(this.icon, this.title, this.subtitle, this.onTap, {this.locked = false});
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;
  final bool locked;
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Icon(icon, size: 34, color: cs.primary),
              if (locked) const Icon(Icons.lock_outline, size: 18),
            ]),
            const Spacer(),
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
          ]),
        ),
      ),
    );
  }
}
