import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RecentFile {
  RecentFile(this.path, this.name, this.size, this.ms);
  final String path, name;
  final int size, ms;
  String get ext => p.extension(name).toLowerCase();
  DateTime get modified => DateTime.fromMillisecondsSinceEpoch(ms);
  Map<String, Object> toJson() => {'p': path, 'n': name, 's': size, 'm': ms};
  static RecentFile fromJson(Map<String, dynamic> j) =>
      RecentFile(j['p'] as String, j['n'] as String, j['s'] as int, j['m'] as int);
}

/// Permission-free "recent documents": every file the user opens through the
/// system picker is copied into the app's private storage and listed here.
class RecentFiles {
  static const _key = 'recent_files_v1';
  static const maxItems = 20;

  static Future<Directory> _dir() async {
    final d = Directory(p.join((await getApplicationDocumentsDirectory()).path, 'recent'));
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  static Future<List<RecentFile>> list() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    try {
      final all = (jsonDecode(raw) as List)
          .map((e) => RecentFile.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
      return all.where((f) => File(f.path).existsSync()).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<RecentFile> addFile(String srcPath) async {
    final name = p.basename(srcPath);
    final dest = File(p.join((await _dir()).path, '${DateTime.now().microsecondsSinceEpoch}_$name'));
    await File(srcPath).copy(dest.path);
    return _register(dest, name);
  }

  static Future<RecentFile> addBytes(String name, Uint8List bytes) async {
    final dest = File(p.join((await _dir()).path, '${DateTime.now().microsecondsSinceEpoch}_$name'));
    await dest.writeAsBytes(bytes, flush: true);
    return _register(dest, name);
  }

  static Future<RecentFile> _register(File f, String name) async {
    final rec = RecentFile(f.path, name, await f.length(), DateTime.now().millisecondsSinceEpoch);
    final items = [rec, ...await list()];
    while (items.length > maxItems) {
      final old = items.removeLast();
      try { await File(old.path).delete(); } catch (_) {}
    }
    await _save(items);
    return rec;
  }

  static Future<void> remove(RecentFile f) async {
    try { await File(f.path).delete(); } catch (_) {}
    final items = (await list()).where((e) => e.path != f.path).toList();
    await _save(items);
  }

  static Future<void> _save(List<RecentFile> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(items.map((e) => e.toJson()).toList()));
  }
}
