import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import '../core/utils.dart';
import '../monetization/banner_ad_widget.dart';
import 'pdf_viewer_screen.dart';
import 'recent_files.dart';

class ReaderHomeScreen extends StatefulWidget {
  const ReaderHomeScreen({super.key});
  @override
  State<ReaderHomeScreen> createState() => _ReaderHomeScreenState();
}

class _ReaderHomeScreenState extends State<ReaderHomeScreen> {
  List<RecentFile> _files = [];
  bool _loading = true;
  String _filter = 'All';

  static const Map<String, Set<String>?> _filters = {
    'All': null,
    'PDF': {'.pdf'},
    'Word': {'.doc', '.docx'},
    'Excel': {'.xls', '.xlsx'},
    'Text': {'.txt'},
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await RecentFiles.list();
    if (mounted) setState(() { _files = l; _loading = false; });
  }

  Future<void> _open(String path, String name) async {
    if (name.toLowerCase().endsWith('.pdf')) {
      await pushPage(context, PdfViewerScreen(path: path));
      return;
    }
    final r = await OpenFilex.open(path);
    if (r.type != ResultType.done && mounted) {
      showSnack(context, 'No app found to open this file. Install an Office viewer.');
    }
  }

  // System picker (SAF): no storage permission needed.
  Future<void> _browse() async {
    try {
      final r = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt'],
      );
      final path = r?.files.single.path;
      if (path == null) return;
      final rec = await RecentFiles.addFile(path);
      await _load();
      if (mounted) await _open(rec.path, rec.name);
    } catch (_) {
      if (mounted) showSnack(context, 'Could not open that file.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final allowed = _filters[_filter];
    final shown = allowed == null ? _files : _files.where((f) => allowed.contains(f.ext)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Documents')),
      bottomNavigationBar: const BannerAdWidget(),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _browse,
        icon: const Icon(Icons.folder_open),
        label: const Text('Browse'),
      ),
      body: Column(children: [
        SizedBox(
          height: 52,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: [
              for (final k in _filters.keys)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(k),
                    selected: _filter == k,
                    onSelected: (_) => setState(() => _filter = k),
                  ),
                ),
            ],
          ),
        ),
        Expanded(child: _body(shown)),
      ]),
    );
  }

  Widget _body(List<RecentFile> shown) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (shown.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text('No recent documents.\nTap Browse to open a PDF, Word, Excel or text file.',
              textAlign: TextAlign.center),
        ),
      );
    }
    return ListView.separated(
      itemCount: shown.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (_, i) {
        final f = shown[i];
        return ListTile(
          leading: Icon(_iconFor(f.ext), color: _colorFor(f.ext)),
          title: Text(f.name, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${formatBytes(f.size)} · ${f.modified.toString().substring(0, 10)}'),
          trailing: IconButton(
            tooltip: 'Remove from recent',
            icon: const Icon(Icons.close),
            onPressed: () async { await RecentFiles.remove(f); await _load(); },
          ),
          onTap: () => _open(f.path, f.name),
        );
      },
    );
  }

  IconData _iconFor(String e) => switch (e) {
        '.pdf' => Icons.picture_as_pdf,
        '.doc' || '.docx' => Icons.description,
        '.xls' || '.xlsx' => Icons.table_chart,
        _ => Icons.text_snippet,
      };

  Color _colorFor(String e) => switch (e) {
        '.pdf' => Colors.red,
        '.doc' || '.docx' => Colors.blue,
        '.xls' || '.xlsx' => Colors.green,
        _ => Colors.grey,
      };
}
