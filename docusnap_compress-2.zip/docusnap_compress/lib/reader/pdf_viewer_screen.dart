import '../core/app_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../core/utils.dart';
import '../monetization/banner_ad_widget.dart';
import '../monetization/premium_controller.dart';

class PdfViewerScreen extends StatefulWidget {
  const PdfViewerScreen({super.key, required this.path});
  final String path;
  @override
  State<PdfViewerScreen> createState() => _PdfViewerScreenState();
}

class _PdfViewerScreenState extends State<PdfViewerScreen> {
  PDFViewController? _ctrl;
  int _pages = 0, _page = 0;
  bool _night = false;
  String? _error;

  Future<void> _jump() async {
    final c = TextEditingController();
    final n = await showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Go to page (1–$_pages)'),
        content: TextField(
          controller: c, autofocus: true,
          keyboardType: TextInputType.number,
          onSubmitted: (v) => Navigator.pop(context, int.tryParse(v)),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(context, int.tryParse(c.text)),
            child: const Text('Go')),
        ],
      ),
    );
    c.dispose();
    if (n != null && n >= 1 && n <= _pages) {
      await _ctrl?.setPage(n - 1);
    } else if (n != null && mounted) {
      showSnack(context, 'Enter a page between 1 and $_pages');
    }
  }

  @override
  Widget build(BuildContext context) {
    final premium = context.watch<PremiumController>().isPremium;
    return Scaffold(
      appBar: AppBar(
        title: Text(p.basename(widget.path), overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'Night mode',
            icon: Icon(_night ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => setState(() => _night = !_night),
          ),
          IconButton(
            tooltip: 'Go to page',
            icon: const Icon(Icons.pin_outlined),
            onPressed: _pages > 0 ? _jump : null,
          ),
        ],
      ),
      bottomNavigationBar: const BannerAdWidget(),
      body: _error != null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!)))
          : Stack(children: [
              PDFView(
                filePath: widget.path,
                enableSwipe: true,
                swipeHorizontal: false,
                autoSpacing: true,
                pageFling: false,
                nightMode: _night, // pinch-to-zoom is built in
                onRender: (n) => setState(() => _pages = n ?? 0),
                onViewCreated: (c) => _ctrl = c,
                onPageChanged: (pg, _) => setState(() => _page = pg ?? 0),
                onError: (e) => setState(() => _error =
                    'Could not open this PDF (it may be corrupted or password-protected).'),
                onPageError: (pg, e) {},
              ),
              if (_pages > 0)
                Positioned(
                  left: 12, bottom: 12,
                  child: Chip(label: Text('${_page + 1} / $_pages')),
                ),
              // Free-tier watermark; Premium removes it.
              if (!premium && !AppConfig.adsOnly)
                const Positioned(
                  right: 12, bottom: 12,
                  child: IgnorePointer(
                    child: Text('DocuSnap',
                        style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w600)),
                  ),
                ),
            ]),
    );
  }
}
