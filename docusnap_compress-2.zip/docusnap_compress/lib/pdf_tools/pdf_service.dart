import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path/path.dart' as p;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdfx/pdfx.dart';

class PdfLimits {
  /// Pages/images anyone can convert with no ad.
  static const freeNoAd = 10;

  /// Hard caps (memory safety). Above [freeNoAd], free users watch ONE
  /// rewarded video ad per conversion; Premium users never see it.
  static const maxImagesToPdf = 50;
  static const maxPdfToImage = 100;
}

class PdfService {
  /// Images → one PDF. Each image is downscaled/re-encoded natively first
  /// (keeps memory low and the PDF small). [quality] 40–95.
  static Future<Uint8List> imagesToPdf(
    List<String> paths, {
    int quality = 80,
    int maxSide = 1800,
    bool a4 = true,
    void Function(int done, int total)? onProgress,
  }) async {
    final doc = pw.Document();
    for (var i = 0; i < paths.length; i++) {
      final bytes = await FlutterImageCompress.compressWithFile(
        paths[i],
        quality: quality,
        minWidth: maxSide,
        minHeight: maxSide,
        format: CompressFormat.jpeg,
        autoCorrectionAngle: true,
      );
      if (bytes == null) throw Exception('Could not read ${p.basename(paths[i])}');
      final image = pw.MemoryImage(bytes);
      if (a4) {
        doc.addPage(pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(12),
          build: (_) => pw.Center(child: pw.Image(image, fit: pw.BoxFit.contain)),
        ));
      } else {
        // Page sized exactly to the image (no white borders).
        final w = (image.width ?? 595).toDouble();
        final h = (image.height ?? 842).toDouble();
        doc.addPage(pw.Page(
          pageFormat: PdfPageFormat(w, h),
          margin: pw.EdgeInsets.zero,
          build: (_) => pw.Image(image, fit: pw.BoxFit.fill),
        ));
      }
      onProgress?.call(i + 1, paths.length);
    }
    return doc.save();
  }

  static Future<int> pageCount(String path) async {
    final doc = await PdfDocument.openFile(path);
    try {
      return doc.pagesCount;
    } finally {
      await doc.close();
    }
  }

  /// PDF pages [from]..[to] (1-based) → images, one page at a time so memory
  /// stays flat. Each image is handed to [onPage] and then released.
  static Future<int> pdfToImages(
    String path, {
    required int from,
    required int to,
    required Future<void> Function(Uint8List bytes, int page) onPage,
    bool png = false,
    double scale = 2.0,
    void Function(int done, int total)? onProgress,
  }) async {
    final doc = await PdfDocument.openFile(path);
    try {
      final end = math.min(to, doc.pagesCount);
      final total = end - from + 1;
      var n = 0;
      for (var i = from; i <= end; i++) {
        final page = await doc.getPage(i);
        try {
          // Cap the longest side at 3000px so big pages can't exhaust memory.
          final s = math.min(scale, 3000 / math.max(page.width, page.height));
          final img = await page.render(
            width: page.width * s,
            height: page.height * s,
            format: png ? PdfPageImageFormat.png : PdfPageImageFormat.jpeg,
            backgroundColor: '#FFFFFF',
            quality: 90,
          );
          if (img != null) {
            await onPage(img.bytes, i);
            n++;
          }
        } finally {
          await page.close();
        }
        onProgress?.call(i - from + 1, total);
      }
      return n;
    } finally {
      await doc.close();
    }
  }
}
