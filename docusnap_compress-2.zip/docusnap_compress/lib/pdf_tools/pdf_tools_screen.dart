import '../core/app_config.dart';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import '../core/utils.dart';
import '../monetization/ad_manager.dart';
import '../monetization/banner_ad_widget.dart';
import '../monetization/paywall_screen.dart';
import '../monetization/premium_controller.dart';
import '../reader/pdf_viewer_screen.dart';
import '../reader/recent_files.dart';
import 'pdf_service.dart';

/// Free users: >10 pages needs one rewarded video. Premium: never asked.
Future<bool> _confirmLargeJob(BuildContext context, int pages) async {
  final premium = context.read<PremiumController>().isPremium;
  if (premium || pages <= PdfLimits.freeNoAd) return true;
  final ads = context.read<AdManager>();
  final go = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      title: const Text('Watch a short video?'),
      content: Text('Up to ${PdfLimits.freeNoAd} pages are free. For $pages pages, '
          'watch one short video ad to continue.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Not now')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Watch video')),
      ],
    ),
  );
  if (go != true) return false;
  final earned = await ads.showRewarded();
  if (!earned && context.mounted) {
    showSnack(context,
        'Video unavailable or not finished. Try again, or use ${PdfLimits.freeNoAd} pages or fewer.');
  }
  return earned;
}

class PdfToolsScreen extends StatelessWidget {
  const PdfToolsScreen({super.key});
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('PDF Tools'),
            bottom: const TabBar(tabs: [Tab(text: 'Image → PDF'), Tab(text: 'PDF → Image')]),
          ),
          bottomNavigationBar: const BannerAdWidget(),
          body: const TabBarView(children: [_ImagesToPdfTab(), _PdfToImagesTab()]),
        ),
      );
}

// ───────────────────────── Image → PDF ─────────────────────────
class _ImagesToPdfTab extends StatefulWidget {
  const _ImagesToPdfTab();
  @override
  State<_ImagesToPdfTab> createState() => _ImagesToPdfTabState();
}

class _ImagesToPdfTabState extends State<_ImagesToPdfTab> {
  final _picker = ImagePicker();
  final List<String> _paths = [];
  int _quality = 80;
  bool _a4 = true, _busy = false;
  RecentFile? _last;

  int get _limit => PdfLimits.maxImagesToPdf;

  Future<void> _add() async {
    final room = _limit - _paths.length;
    if (room <= 0) {
      _limitHit();
      return;
    }
    try {
      final List<XFile> picks;
      if (room == 1) {
        final one = await _picker.pickImage(source: ImageSource.gallery);
        picks = one == null ? [] : [one];
      } else {
        picks = await _picker.pickMultiImage(limit: room);
      }
      if (picks.isEmpty) return;
      setState(() => _paths.addAll(picks.take(room).map((e) => e.path)));
      if (picks.length > room) _limitHit();
    } catch (_) {
      if (mounted) showSnack(context, 'Could not open images.');
    }
  }

  void _limitHit() => showSnack(context, 'Maximum $_limit images per PDF.');

  Future<void> _create() async {
    if (!await _confirmLargeJob(context, _paths.length)) return;
    setState(() { _busy = true; _last = null; });
    try {
      final bytes = await PdfService.imagesToPdf(_paths, quality: _quality, a4: _a4);
      final name = 'docusnap_${DateTime.now().millisecondsSinceEpoch}.pdf';
      // System "save as" dialog: no storage permission needed.
      final saved = await FilePicker.platform.saveFile(
        dialogTitle: 'Save PDF',
        fileName: name,
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        bytes: bytes,
      );
      if (saved == null) {
        if (mounted) showSnack(context, 'Save cancelled.');
        return;
      }
      final rec = await RecentFiles.addBytes(name, bytes);
      if (!mounted) return;
      setState(() => _last = rec);
      showSnack(context, 'PDF saved (${formatBytes(bytes.length)}).');
      await context.read<AdManager>().showInterstitialAfterSave();
    } catch (e) {
      if (mounted) showSnack(context, 'Could not create the PDF. Try fewer or smaller images.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final premium = context.watch<PremiumController>().isPremium;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('${_paths.length} / ${PdfLimits.maxImagesToPdf} images'
          '${premium ? '' : ' · up to ${PdfLimits.freeNoAd} with no ad'}',
          style: Theme.of(context).textTheme.titleSmall),
      const SizedBox(height: 8),
      if (_paths.isNotEmpty)
        SizedBox(
          height: 100,
          child: ReorderableListView(
            scrollDirection: Axis.horizontal,
            buildDefaultDragHandles: true,
            onReorder: (o, n) => setState(() {
              if (n > o) n--;
              _paths.insert(n, _paths.removeAt(o));
            }),
            children: [
              for (var i = 0; i < _paths.length; i++)
                Padding(
                  key: ValueKey('${_paths[i]}#$i'),
                  padding: const EdgeInsets.only(right: 8),
                  child: Stack(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(File(_paths[i]), width: 80, height: 100,
                          fit: BoxFit.cover, cacheWidth: 200),
                    ),
                    Positioned(
                      right: 0, top: 0,
                      child: InkWell(
                        onTap: () => setState(() => _paths.removeAt(i)),
                        child: const CircleAvatar(radius: 10, child: Icon(Icons.close, size: 12)),
                      ),
                    ),
                    Positioned(
                      left: 4, bottom: 4,
                      child: CircleAvatar(radius: 9, child: Text('${i + 1}', style: const TextStyle(fontSize: 10))),
                    ),
                  ]),
                ),
            ],
          ),
        ),
      if (_paths.length > 1)
        const Padding(
          padding: EdgeInsets.only(top: 4),
          child: Text('Long-press and drag to reorder pages.'),
        ),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: _busy ? null : _add,
        icon: const Icon(Icons.add_photo_alternate_outlined),
        label: const Text('Add images'),
      ),
      const SizedBox(height: 16),
      Text('Page size', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      SegmentedButton<bool>(
        segments: const [
          ButtonSegment(value: true, label: Text('A4 page')),
          ButtonSegment(value: false, label: Text('Fit to image')),
        ],
        selected: {_a4},
        onSelectionChanged: (s) => setState(() => _a4 = s.first),
      ),
      const SizedBox(height: 16),
      Text('Quality / file size', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      SegmentedButton<int>(
        segments: const [
          ButtonSegment(value: 55, label: Text('Small')),
          ButtonSegment(value: 80, label: Text('Medium')),
          ButtonSegment(value: 92, label: Text('High')),
        ],
        selected: {_quality},
        onSelectionChanged: (s) => setState(() => _quality = s.first),
      ),
      const SizedBox(height: 20),
      FilledButton.icon(
        onPressed: (_paths.isEmpty || _busy) ? null : _create,
        icon: _busy
            ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
            : const Icon(Icons.picture_as_pdf),
        label: Text(_busy ? 'Creating…' : 'Create PDF'),
        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
      ),
      if (_last != null)
        Card(
          margin: const EdgeInsets.only(top: 16),
          child: ListTile(
            leading: const Icon(Icons.check_circle, color: Colors.green),
            title: Text(_last!.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(formatBytes(_last!.size)),
            trailing: TextButton(
              onPressed: () => pushPage(context, PdfViewerScreen(path: _last!.path)),
              child: const Text('Open'),
            ),
          ),
        ),
    ]);
  }
}

// ───────────────────────── PDF → Image ─────────────────────────
class _PdfToImagesTab extends StatefulWidget {
  const _PdfToImagesTab();
  @override
  State<_PdfToImagesTab> createState() => _PdfToImagesTabState();
}

class _PdfToImagesTabState extends State<_PdfToImagesTab> {
  final _fromCtrl = TextEditingController(text: '1');
  final _toCtrl = TextEditingController();
  String? _path;
  int _pages = 0;
  bool _png = false, _busy = false;
  int _done = 0, _total = 0;

  @override
  void dispose() {
    _fromCtrl.dispose();
    _toCtrl.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    try {
      final r = await FilePicker.platform.pickFiles(
        type: FileType.custom, allowedExtensions: ['pdf']);
      final path = r?.files.single.path;
      if (path == null) return;
      final n = await PdfService.pageCount(path);
      final limit = context.read<PremiumController>().isPremium
          ? PdfLimits.maxPdfToImage
          : PdfLimits.freeNoAd;
      setState(() {
        _path = path;
        _pages = n;
        _fromCtrl.text = '1';
        _toCtrl.text = '${n < limit ? n : limit}';
      });
    } catch (_) {
      if (mounted) showSnack(context, 'Could not open this PDF (corrupted or password-protected?).');
    }
  }

  Future<void> _convert() async {
    const limit = PdfLimits.maxPdfToImage;
    final from = (int.tryParse(_fromCtrl.text) ?? 1).clamp(1, _pages).toInt();
    var to = (int.tryParse(_toCtrl.text) ?? _pages).clamp(from, _pages).toInt();
    if (to - from + 1 > limit) {
      to = from + limit - 1;
      showSnack(context, 'Max $limit pages at a time.');
    }
    if (!await _confirmLargeJob(context, to - from + 1)) return;
    setState(() { _busy = true; _done = 0; _total = to - from + 1; });
    try {
      final dir = await getTemporaryDirectory();
      final base = p.basenameWithoutExtension(_path!);
      final ext = _png ? 'png' : 'jpg';
      final n = await PdfService.pdfToImages(
        _path!, from: from, to: to, png: _png,
        onProgress: (d, t) { if (mounted) setState(() => _done = d); },
        onPage: (bytes, page) async {
          final f = File(p.join(dir.path, '${base}_p$page.$ext'));
          await f.writeAsBytes(bytes, flush: true);
          await Gal.putImage(f.path, album: 'DocuSnap');
          await f.delete();
        },
      );
      if (!mounted) return;
      showSnack(context, 'Saved $n image(s) to Gallery › DocuSnap');
      await context.read<AdManager>().showInterstitialAfterSave();
    } on GalException catch (e) {
      if (mounted) showSnack(context, 'Could not save: ${e.type.message}');
    } catch (_) {
      if (mounted) showSnack(context, 'Conversion failed. The PDF may be protected or too large.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final premium = context.watch<PremiumController>().isPremium;
    return ListView(padding: const EdgeInsets.all(16), children: [
      OutlinedButton.icon(
        onPressed: _busy ? null : _pick,
        icon: const Icon(Icons.upload_file),
        label: Text(_path == null ? 'Choose a PDF' : p.basename(_path!)),
      ),
      if (_path != null) ...[
        const SizedBox(height: 8),
        Text('$_pages page(s)'),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(child: _numField(_fromCtrl, 'From page')),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('to')),
          Expanded(child: _numField(_toCtrl, 'To page')),
        ]),
        const SizedBox(height: 4),
        Text(premium
            ? 'Up to ${PdfLimits.maxPdfToImage} pages per conversion.'
            : 'Up to ${PdfLimits.freeNoAd} pages free. More pages (max ${PdfLimits.maxPdfToImage}): watch one short video.',
            style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 16),
        SegmentedButton<bool>(
          segments: const [
            ButtonSegment(value: false, label: Text('JPG')),
            ButtonSegment(value: true, label: Text('PNG')),
          ],
          selected: {_png},
          onSelectionChanged: (s) => setState(() => _png = s.first),
        ),
        const SizedBox(height: 20),
        if (_busy) ...[
          LinearProgressIndicator(value: _total == 0 ? null : _done / _total),
          const SizedBox(height: 4),
          Text('Page $_done / $_total'),
          const SizedBox(height: 12),
        ],
        FilledButton.icon(
          onPressed: _busy ? null : _convert,
          icon: const Icon(Icons.image_outlined),
          label: const Text('Convert & save to Gallery'),
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
        ),
        const SizedBox(height: 8),
        Text('Tip: use the Photo Compressor afterwards to shrink a page image to an exact KB size.',
            style: Theme.of(context).textTheme.bodySmall),
      ],
    ]);
  }

  Widget _numField(TextEditingController c, String l) => TextField(
        controller: c,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(labelText: l, isDense: true, border: const OutlineInputBorder()),
      );
}
