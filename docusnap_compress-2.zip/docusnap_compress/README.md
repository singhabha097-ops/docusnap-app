# DocuSnap & Compress (Flutter)

> Written without a Flutter SDK or network access, so it has **not been compiled or run**.
> Expect small API fixes after `flutter pub get`. Versions are from memory:
> run `flutter pub upgrade --major-versions`.

## Features
Photo compressor (exact KB target, px/cm sizing, JPG/PNG/WebP, batch for Premium) ·
Editor (crop incl. passport, rotate, flip, brightness, contrast, B&W) ·
**Image → PDF** and **PDF → Image** · PDF reader (zoom, page jump, night mode) ·
Recent documents + system file picker · AdMob (free users only) ·
Play Billing: Monthly ₹49, Annual ₹499, **Lifetime ₹999**.

## Structure
```
lib/
├─ main.dart
├─ core/utils.dart
├─ home/home_screen.dart
├─ compressor/        compression_engine.dart, compressor_screen.dart
├─ editor/            editor_service.dart, editor_screen.dart
├─ pdf_tools/         pdf_service.dart, pdf_tools_screen.dart
├─ reader/            recent_files.dart, reader_home_screen.dart, pdf_viewer_screen.dart
└─ monetization/      premium_controller, ad_manager, banner_ad_widget, billing_service, paywall_screen
```

## Setup
1. `flutter create --org com.yourco --project-name docusnap_compress .` in an empty folder,
   then copy `lib/` and `pubspec.yaml` over the generated ones.
2. Replace `android/app/src/main/AndroidManifest.xml` with `android_config/AndroidManifest.xml`.
3. `android/app/build.gradle(.kts)`: `minSdk = 24`.
4. UCrop needs an AppCompat theme (`Theme.AppCompat.Light.NoActionBar` must resolve).
5. Keep the Google TEST AdMob IDs while developing. Swap in your own only at launch.
6. `flutter pub get && flutter run`

## Permissions (Play-policy safe)
| Permission | Why |
|---|---|
| INTERNET, ACCESS_NETWORK_STATE | AdMob, Play Billing |
| AD_ID | AdMob on Android 13+ |
| WRITE_EXTERNAL_STORAGE (max SDK 28) | gallery save on old phones only |

No broad storage permission: gallery photos use the system Photo Picker, documents use the
system file picker, and PDFs are saved through the system "Save as" dialog. Opened documents
are copied into app-private storage to power the **Recent files** list (last 20).

## Play Console products (when you publish)
- Subscriptions: `sub_monthly_49` (₹49/month), `sub_annual_499` (₹499/year), one base plan each.
- One-time product: `lifetime_999` (₹999).
- Set US/UK/EU prices manually instead of letting Play auto-convert.
- Billing only works from a Play-distributed build (internal testing is enough).

## Free vs Premium
| | Free | Premium |
|---|---|---|
| Ads | banner + cooldown interstitial | none |
| Image → PDF | 10 pages free; up to 50 after one video ad | up to 50, no ad |
| PDF → Image | 10 pages free; up to 100 after one video ad | up to 100, no ad |
| Batch compress | no | 20 images |
| PDF viewer watermark | "DocuSnap" label | none |

## Limitations
- Premium is verified on-device only (no server): a rooted phone could spoof it. Add RevenueCat
  or server-side token checks before relying on real revenue.
- Lifetime purchases never expire locally; refunds are not detected without a server.
- Subscription premium survives 3 days offline without a Play re-check.
- PNG is lossless: tiny KB targets shrink pixel size. WebP is encoded natively.
- DOCX/XLSX/PPTX open in an installed viewer app (no in-app Office rendering).
- Password-protected PDFs can't be converted.
- Ads: use test ads only. Never click your own live ads (can get AdMob banned).

## Ads-only edition (Samsung Galaxy Store, Indus AppStore, other non-Google stores)
Play Billing only works on Google Play, so these stores get a free, ads-only build.

1. Build with the flag: `flutter build apk --release --dart-define=ADS_ONLY=true`
   (no paywall, no billing init, no Premium upsell, no PDF watermark; ads still run).
2. Use a **different package name** from your Play build (Samsung recommends this).
   Add flavors in `android/app/build.gradle.kts`:
   ```kotlin
   android {
       flavorDimensions += "store"
       productFlavors {
           create("play") { dimension = "store" }
           create("alt")  { dimension = "store"; applicationIdSuffix = ".alt" }
       }
   }
   ```
   Then: `flutter build apk --release --flavor alt --dart-define=ADS_ONLY=true`
   and for Play: `flutter build appbundle --release --flavor play`.
3. Samsung: register at https://seller.samsungapps.com, request commercial seller status
   if you need it, upload the APK (AAB needs Galaxy Store signing). Indus AppStore: check its
   current developer terms. Both are separate review processes.
4. The billing plugin still adds the `com.android.vending.BILLING` permission to the manifest;
   it is harmless but a store reviewer may ask about it. Remove it with
   `<uses-permission android:name="com.android.vending.BILLING" tools:node="remove"/>`
   in the `alt` flavor manifest if needed.
5. Paid plans (Monthly/Annual/Lifetime) exist only in the Play build. Adding Samsung IAP or
   Indus payments later means a new billing service behind the same `PremiumController`.

## Rewarded video ads
Free users (Play and ads-only builds) convert up to 10 pages with no ad. For 11+ pages the app asks first
("Watch a short video?") and runs one rewarded ad per conversion. It is always opt-in. Swap the test
rewarded unit ID in `AdIds.rewarded` for your own before release.
